package com.aftcodex;

import android.os.Bundle;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class CertificateActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_certificate);

        TextView certificateText = findViewById(R.id.certificateText);
        certificateText.setText(getString(R.string.certificate_text));
    }
}
